package event.node;

/**
 * 
 * @author Tom Leaman (thl5@aber.ac.uk)
 *
 */
public class JunctionNode extends Node {

	public JunctionNode(int id) {
		super(id);
	}

}
