package event.node;

/**
 * 
 * @author Tom Leaman (thl5@aber.ac.uk)
 *
 */
public class CheckpointNode extends Node {

	public CheckpointNode(int id) {
		super(id);
	}

}
