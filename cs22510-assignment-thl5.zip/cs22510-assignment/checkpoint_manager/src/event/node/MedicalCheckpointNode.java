package event.node;

/**
 * 
 * @author Tom Leaman (thl5@aber.ac.uk)
 *
 */
public class MedicalCheckpointNode extends Node {

	public MedicalCheckpointNode(int id) {
		super(id);
	}

}
